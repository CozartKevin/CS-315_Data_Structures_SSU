//
// Created by Kevin on 9/17/2019.
//
#include <vector>

#ifndef COUNT_INVERSIONS_COUNT_INVERSIONS_RECURSIVE_HPP
#define COUNT_INVERSIONS_COUNT_INVERSIONS_RECURSIVE_HPP
int count_Inversion(std::vector<int> &InputVector, int vSize);
#endif //COUNT_INVERSIONS_COUNT_INVERSIONS_RECURSIVE_HPP

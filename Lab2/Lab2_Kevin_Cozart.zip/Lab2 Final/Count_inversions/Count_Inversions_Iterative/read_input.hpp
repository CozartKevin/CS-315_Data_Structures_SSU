//
// Created by Kevin on 9/17/2019.
//

#include <vector>
#include <string>
#ifndef ITERATIVE_READ_INPUT_HPP
#define ITERATIVE_READ_INPUT_HPP
void read_numbers(std::string fileName, std::vector<int> &v);
#endif //ITERATIVE_READ_INPUT_HPP

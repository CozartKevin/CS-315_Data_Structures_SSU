//
// Created by Kevin on 9/17/2019.
//
#include <vector>

#ifndef LARGER_ELEMENTS_LEFT_RECURSIVE_HPP
#define LARGER_ELEMENTS_LEFT_RECURSIVE_HPP
void largest_left_recursive(const std::vector<int> &numbers, std::vector<int> &result, int n);
void check_Rest_Vect(const std::vector<int> &InputVector,std::vector<int> &OutputVector, int currentVectorLocation, int decrementVectorLocation);

#endif //LARGER_ELEMENTS_LEFT_RECURSIVE_HPP

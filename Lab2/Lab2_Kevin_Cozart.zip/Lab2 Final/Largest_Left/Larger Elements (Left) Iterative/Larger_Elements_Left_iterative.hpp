//
// Created by Kevin on 9/17/2019.
//
#include <vector>

#ifndef LARGER_ELEMENTS_LEFT_ITERATIVE_HPP
#define LARGER_ELEMENTS_LEFT_ITERATIVE_HPP
void larger_Elements_Left(std::vector<int> &InputVector, std::vector<int> &OutputVector);
void check_Rest_Vect(std::vector<int> &InputVector,std::vector<int> &OutputVector, int currentVectorLocation);

#endif //LARGER_ELEMENTS_LEFT_ITERATIVE_HPP

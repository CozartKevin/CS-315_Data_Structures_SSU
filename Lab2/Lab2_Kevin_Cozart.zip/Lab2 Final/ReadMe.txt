LAB 2 Kevin Cozart

All Iterative and Recursive programs function as requested. 

Input file (input.txt) needs to be placed in the cmake-build-debug folder in each project.
There is already an input.txt that I have been using inside this folder, just replace with your input file to test. NOTE: Must be named "input.txt"


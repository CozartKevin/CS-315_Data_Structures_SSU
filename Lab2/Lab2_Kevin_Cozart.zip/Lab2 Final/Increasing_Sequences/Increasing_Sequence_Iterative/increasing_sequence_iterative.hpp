//
// Created by Kevin on 9/17/2019.
//
#include <vector>

#ifndef INCREASING_SEQUENCE_ITERATIVE_HPP
#define INCREASING_SEQUENCE_ITERATIVE_HPP
int increasing_sequence_iterative(std::vector<int> &numbers);
#endif //INCREASING_SEQUENCE_ITERATIVE_HPP

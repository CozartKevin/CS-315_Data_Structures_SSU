//
// Created by Kevin on 9/17/2019.
//
#include <vector>

#ifndef INCREASING_SEQUENCE_RECURSIVE_HPP
#define INCREASING_SEQUENCE_RECURSIVE_HPP
int increasing_sequence_recursive(std::vector<int> &numbers, int startIdx);
#endif //INCREASING_SEQUENCE_RECURSIVE_HPP

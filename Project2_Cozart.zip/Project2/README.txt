Project 2 - Kevin Cozart README.txt

program functions as per the outline specs for the project. 

Pulls data from prev_pp.json and cur_pp.json and outputs their intersection based on ID into cs315project2.json.
program also prints out the output to console. 
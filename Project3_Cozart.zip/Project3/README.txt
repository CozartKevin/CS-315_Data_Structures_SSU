Project 3 - Kevin Cozart

This program works as required.

Place any assignment statements you want run in the index.txt file in the root of the project. 


Output as follows: 
Where the first grouping is the input assignment statements
and the second grouping is the answer to those statements

 b  =  XII EOL
 c  =  MMDCCCLXXXVIII  +  b EOL
 b  =  c  -  b EOL
 a  = ( M  +  X  *  II  +  IV ) *  II EOL

b equals XII
c equals MMCM
b equals MMDCCCLXXXVIII
a equals MMXLVIII
Project 1 Kevin Cozart README

All functions of this lab are functioning to spec including permute. 

